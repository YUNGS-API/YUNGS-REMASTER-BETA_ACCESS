package com.yungnickyoung.minecraft.betterdungeons.world;

import java.lang.ref.WeakReference;

/**
 * Stores information during small dungeon generation for later use.
 */
public class DungeonContext {
    private static final ThreadLocal<DungeonContext> CONTEXT = new ThreadLocal<>();

    private WeakReference<Integer> bannerCount;
    private WeakReference<Integer> chestCount;

    public DungeonContext() {
        this.bannerCount = new WeakReference<>(0);
        this.chestCount = new WeakReference<>(0);
    }

    public int getBannerCount() {
        Integer value = bannerCount.get();
        return value == null ? 0 : value;
    }

    public int getChestCount() {
        Integer value = chestCount.get();
        return value == null ? 0 : value;
    }

    public void incrementBannerCount() {
        Integer boxedVal = bannerCount.get();
        int val = boxedVal == null ? 0 : boxedVal;
        bannerCount.clear();
        bannerCount = new WeakReference<>(val + 1);
    }

    public void incrementChestCount() {
        Integer boxedVal = chestCount.get();
        int val = boxedVal == null ? 0 : boxedVal;
        chestCount.clear();
        chestCount = new WeakReference<>(val + 1);
    }

    /**
     * Consume the currently held DungeonContext.
     * A null value means the context has already been consumed.
     */
    public static DungeonContext pop() {
        DungeonContext context = CONTEXT.get();
        CONTEXT.set(null);
        return context;
    }

    /**
     * Peek the currently held DungeonContext without consuming it.
     * A null value means the context has already been consumed.
     */
    public static DungeonContext peek() {
        return CONTEXT.get();
    }

    /**
     * Should only be called right before structure processing,
     * so that processors can be guaranteed to retrieve the proper context.
     */
    public static void initialize() {
        CONTEXT.set(new DungeonContext());
    }
}
